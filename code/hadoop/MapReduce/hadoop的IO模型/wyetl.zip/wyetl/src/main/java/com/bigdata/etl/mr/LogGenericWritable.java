package com.bigdata.etl.mr;

import com.alibaba.fastjson.JSONObject;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableUtils;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
//编写一个类似于map的类，作用是可以在map端向reduce端传输数据时只传输字段值，字段名传输一次即可
abstract public class LogGenericWritable implements Writable {
    //存储日志数据的value值，LogFiledWritable为自定义的通用genericWritable类
    private LogFieldWritable[] datum;
    //存储日志数据的字段名，也就是key，数组长度与datum一致
    private String[] name;
    //存储value值对应的数组下标
    private Map<String,Integer> nameIndex;
    //提供一个传入name数组的抽象方法
    abstract protected String[] getFieldName();

    public LogGenericWritable(){
        //初始化一个name的数组
        name = getFieldName();
        if (name == null){
            throw new RuntimeException("The filed name cat not be null");
        }
        nameIndex = new HashMap<String,Integer>();
        for (int index = 0; index < name.length ; index ++) {

            //如果字段名已经存在则代表存在重复，抛出异常
            if (nameIndex.containsKey(name[index])){
                new RuntimeException("The filed" + name[index] + "duplicate");
            }
            //将字段名和其下标存入map中
            nameIndex.put(name[index],index);
        }
        //对datum[]进行初始化操作
        datum = new LogFieldWritable[name.length];
        for (int i = 0; i <datum.length ; i++) {
            datum[i] = new LogFieldWritable();
        }

    }

    public void put(String name, LogFieldWritable value){
        //因为构造器中已经对map存入字段名与下标，因此可以获得下标
        int index = getIndexWithName(name);
        //将字段名对应的值存入datum数组，存贮位置和string[] name下标位置一样
        datum[index] = value;
    }
    //返回writable类型的get方法
    public LogFieldWritable getWritable(String name){
        int index = getIndexWithName(name);
        return datum[index];
    }
    //返回Object类型的get方法
    public Object getObject(String name){
        return getWritable(name).getObject();
    }
    //通过字段名获取字段值的数组下标
    private int getIndexWithName(String name){
        Integer index = nameIndex.get(name);
        if (index == null){
            throw new RuntimeException("The filed" + name + "not registered");
        }
        return index;
    }


    public void write(DataOutput out) throws IOException {
        //数组的序列化需要先将数组长度序列化进去
        WritableUtils.writeVInt(out,name.length);
        for (int i = 0; i <name.length ; i++) {
            datum[i].write(out);
        }
    }

    public void readFields(DataInput in) throws IOException {
        int length = WritableUtils.readVInt(in);
        datum =  new LogFieldWritable[length];
        LogFieldWritable value = new LogFieldWritable();
        for (int i = 0; i < length; i++) {
            value.readFields(in);
            datum[i] = value;
        }
    }

    //编写一个json转换string的方法
    public String asJsonString(){
        JSONObject jsonObject = new JSONObject();
        for (int i = 0; i <name.length ; i++) {
            jsonObject.put(name[i],datum[i].getObject());
        }
        return jsonObject.toString();
    }
}
                                                                                                                                                